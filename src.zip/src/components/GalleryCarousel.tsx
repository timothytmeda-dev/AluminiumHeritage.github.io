import useEmblaCarousel from 'embla-carousel-react';
import { useCallback, useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const IMAGES = [
  "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=1000",
  "https://images.unsplash.com/photo-1510074377623-8cf13fb86c08?q=80&w=1000",
  "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?q=80&w=1000",
  "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=1000",
  "https://images.unsplash.com/photo-1503387762-592dea58ef23?q=80&w=1000",
  "https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1000",
  "https://images.unsplash.com/photo-1497366811353-6870744d04b2?q=80&w=1000",
  "https://images.unsplash.com/photo-1497215728101-856f4ea42174?q=80&w=1000",
  "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?q=80&w=1000",
  "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1000",
  "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?q=80&w=1000",
  "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?q=80&w=1000",
  "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?q=80&w=1000",
  "https://images.unsplash.com/photo-1600573472591-ee6b68d14c68?q=80&w=1000",
  "https://images.unsplash.com/photo-1600585154526-990dcea464dd?q=80&w=1000",
  "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?q=80&w=1000",
  "https://images.unsplash.com/photo-1600607687644-c7171b42498f?q=80&w=1000",
  "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=1000",
  "https://images.unsplash.com/photo-1449156001437-3a14427b2331?q=80&w=1000",
  "https://images.unsplash.com/photo-1448630360428-65456885c650?q=80&w=1000",
];

export default function GalleryCarousel() {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true, align: 'center' });
  const [selectedIndex, setSelectedIndex] = useState(0);

  const scrollPrev = useCallback(() => emblaApi && emblaApi.scrollPrev(), [emblaApi]);
  const scrollNext = useCallback(() => emblaApi && emblaApi.scrollNext(), [emblaApi]);

  const onSelect = useCallback(() => {
    if (!emblaApi) return;
    setSelectedIndex(emblaApi.selectedScrollSnap());
  }, [emblaApi, setSelectedIndex]);

  useEffect(() => {
    if (!emblaApi) return;
    onSelect();
    emblaApi.on('select', onSelect);
    emblaApi.on('reInit', onSelect);
  }, [emblaApi, onSelect]);

  return (
    <div className="relative group max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="overflow-hidden" ref={emblaRef}>
        <div className="flex">
          {IMAGES.map((src, index) => (
            <div 
              key={index} 
              className="relative flex-[0_0_80%] min-w-0 md:flex-[0_0_50%] lg:flex-[0_0_33.33%] px-4"
            >
              <div className="aspect-[4/5] overflow-hidden bg-slate-100">
                <img 
                  src={src} 
                  alt={`Installation ${index + 1}`} 
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <button
        className="absolute top-1/2 -left-4 md:left-4 -translate-y-1/2 w-12 h-12 bg-white text-heritage-navy shadow-xl flex items-center justify-center hover:bg-heritage-orange hover:text-white transition-all opacity-0 group-hover:opacity-100 disabled:hidden"
        onClick={scrollPrev}
      >
        <ChevronLeft size={24} />
      </button>

      <button
        className="absolute top-1/2 -right-4 md:right-4 -translate-y-1/2 w-12 h-12 bg-white text-heritage-navy shadow-xl flex items-center justify-center hover:bg-heritage-orange hover:text-white transition-all opacity-0 group-hover:opacity-100 disabled:hidden"
        onClick={scrollNext}
      >
        <ChevronRight size={24} />
      </button>

      <div className="flex justify-center gap-2 mt-8">
        {IMAGES.map((_, index) => (
          <button
            key={index}
            className={`w-1.5 h-1.5 rounded-full transition-all ${
              index === selectedIndex ? 'w-8 bg-heritage-orange' : 'bg-slate-300'
            }`}
             onClick={() => emblaApi?.scrollTo(index)}
          />
        ))}
      </div>
    </div>
  );
}
